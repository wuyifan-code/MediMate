/**
 * Qwen Service (OpenAI Compatible)
 * 替代原有的 Google Gemini 实现
 */

import { OpenAI } from 'openai';

const MODEL_NAME = 'qwen-plus';

// --- Data Classes (Interfaces) ---

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatCompletionRequest {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  top_p?: number;
  max_tokens?: number;
  stream?: boolean;
}

export interface ChatCompletionResponse {
  id: string;
  choices: {
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

// --- OpenAI Client Configuration ---

// 初始化 OpenAI 客户端
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_API_KEY || process.env.API_KEY || process.env.OPENAI_API_KEY,
  baseURL: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
  dangerouslyAllowBrowser: true, // 允许在浏览器环境中使用
});

// --- API Implementation (Retrofit Equivalent) ---

/**
 * 核心请求方法，支持流式和非流式响应
 */
async function executeChatCompletion(
  request: ChatCompletionRequest,
  onStream?: (chunk: string) => void
): Promise<string> {
  try {
    // 如果需要流式响应
    if (request.stream && onStream) {
      const stream = await openai.chat.completions.create({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        top_p: request.top_p,
        max_tokens: request.max_tokens,
        stream: true,
      });

      let fullResponse = '';
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        if (content) {
          fullResponse += content;
          onStream(content); // 回调处理流式数据
        }
      }
      return fullResponse;
    } 
    // 非流式响应
    else {
      const completion = await openai.chat.completions.create({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        top_p: request.top_p,
        max_tokens: request.max_tokens,
        stream: false,
      });

      return completion.choices[0]?.message?.content || '';
    }
  } catch (error) {
    // 增强错误日志
    console.error('Qwen API call failed:', {
      error,
      errorType: typeof error,
      errorMessage: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      request: {
        model: request.model,
        messageCount: request.messages.length,
        stream: request.stream,
      },
      apiKeyConfigured: !!import.meta.env.VITE_API_KEY,
    });
    throw error;
  }
}

// --- ViewModel Logic (Exposed Services) ---

const SYSTEM_INSTRUCTION = `你是一个专业的 MediMate AI 医疗助手。
你的职责是协助用户（患者、家属和陪诊师）：
1. 医疗预检：根据简单症状建议挂号科室。
2. 平台导航：解释如何预约陪诊、价格或服务类型。
3. 通用健康信息：提供常识性健康建议（声明自己不是医生）。
4. 情绪支持：对焦虑的患者保持共情。

语气：专业、温暖、简洁。
语言：使用与用户相同的语言。`;

/**
 * 智能导诊服务
 */
export const getHealthTriage = async (symptoms: string): Promise<string> => {
  try {
    const request: ChatCompletionRequest = {
      model: MODEL_NAME,
      messages: [
        { role: 'system', content: '你是一个专业的医疗预检助手。' },
        { role: 'user', content: `根据以下症状提供挂号建议、准备建议和温馨提示：\n症状：${symptoms}` }
      ],
      temperature: 0.7
    };

    return await executeChatCompletion(request);
  } catch (error) {
    return "服务暂时不可用，请直接前往医院或咨询在线医生。";
  }
};

/**
 * 匹配理由生成服务
 */
export const getMatchReasoning = async (patientNeeds: string, escortProfile: string): Promise<string> => {
  try {
    const request: ChatCompletionRequest = {
      model: MODEL_NAME,
      messages: [
        { role: 'system', content: '你是一个智能匹配助手。' },
        { role: 'user', content: `请用一句话解释为什么这位陪诊师适合该患者：\n患者需求：${patientNeeds}\n陪诊师资料：${escortProfile}` }
      ]
    };

    return await executeChatCompletion(request);
  } catch (error) {
    return "基于地理位置与专业资质智能推荐";
  }
};

/**
 * AI 助手对话服务 (含历史记录和流式支持)
 */
export const getAiAssistantResponse = async (
  message: string, 
  history: { role: 'user' | 'model', parts: [{ text: string }] }[],
  onStream?: (chunk: string) => void
): Promise<string> => {
  try {
    // 将 Gemini 格式的历史记录转换为 OpenAI 格式
    const chatHistory: ChatMessage[] = history.map(h => ({
      role: h.role === 'model' ? 'assistant' : 'user',
      content: h.parts[0].text
    }));

    const request: ChatCompletionRequest = {
      model: MODEL_NAME,
      messages: [
        { role: 'system', content: SYSTEM_INSTRUCTION },
        ...chatHistory,
        { role: 'user', content: message }
      ],
      temperature: 0.8,
      stream: !!onStream // 如果提供了 onStream 回调，则启用流式
    };

    return await executeChatCompletion(request, onStream);
  } catch (error) {
    return "抱歉，通义千问服务暂时连接失败，请稍后再试。";
  }
};